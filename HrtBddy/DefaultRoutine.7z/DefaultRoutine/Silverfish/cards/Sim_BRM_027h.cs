using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_BRM_027h : SimTemplate //Ragnaros the Firelord
    {
        //the hero


    }

}