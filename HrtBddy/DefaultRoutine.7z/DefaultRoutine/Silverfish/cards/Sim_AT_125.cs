using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_125 : SimTemplate //Icehowl
    {

        //Charge + cant attack heros!

        //done in movegenerator
       


    }

}