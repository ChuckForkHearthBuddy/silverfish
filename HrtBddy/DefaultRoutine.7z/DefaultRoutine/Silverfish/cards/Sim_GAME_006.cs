using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_GAME_006 : SimTemplate //noooooooooooo
	{

//    leider wurde die karte, die ihr einst besaßt, entfernt. aber nehmt doch diese hier!


	}
}