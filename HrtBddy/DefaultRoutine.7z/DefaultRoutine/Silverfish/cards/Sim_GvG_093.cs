using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_093 : SimTemplate //Target Dummy
    {

        //   Taunt

        public override void getBattlecryEffect(Playfield p, Minion own, Minion target, int choice)
        {
            
        }

        public override void onCardPlay(Playfield p, bool ownplay, Minion target, int choice)
        {

        }


    }

}