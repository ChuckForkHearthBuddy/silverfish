using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_070 : SimTemplate //Salty Dog
    {

        //   just a pirate

        

    }

}