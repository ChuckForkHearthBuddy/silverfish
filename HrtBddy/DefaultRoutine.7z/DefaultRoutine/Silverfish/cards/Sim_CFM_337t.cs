using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_337t : SimTemplate //* Piranha
	{
		// -
	}
}