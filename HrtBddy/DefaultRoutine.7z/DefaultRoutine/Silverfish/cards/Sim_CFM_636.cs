using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_636 : SimTemplate //* Shadow Rager
	{
		// Stealth
	}
}