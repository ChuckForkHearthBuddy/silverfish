using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_079 : SimTemplate //Force-Tank MAX
    {

        //  Divine Shield 

       

    }

}