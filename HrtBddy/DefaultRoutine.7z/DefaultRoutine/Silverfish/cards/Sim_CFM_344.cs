using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_344 : SimTemplate //* Finja, the Flying Star
	{
		// Stealth. Whenever this attacks and kills a minion, summon 2 Murlocs from your deck.
        //handled
	}
}