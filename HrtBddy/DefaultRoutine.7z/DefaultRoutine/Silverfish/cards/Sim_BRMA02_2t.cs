using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BRMA02_2t : SimTemplate //* Dark Iron Spectator
	{
		//Taunt
	}
}