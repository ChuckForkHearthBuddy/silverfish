using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_KAR_025b : SimTemplate //2/2 Broom
    {

    }
}