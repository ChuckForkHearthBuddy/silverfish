﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_087 : SimTemplate //Argent Horserider
    {

        //charge+div shield

       
    }
}