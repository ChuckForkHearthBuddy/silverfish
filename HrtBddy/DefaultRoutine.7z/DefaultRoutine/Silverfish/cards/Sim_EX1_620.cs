using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_620 : SimTemplate //moltengiant
	{

//    kostet (1) weniger für jeden schadenspunkt, den euer held erlitten hat.


	}
}