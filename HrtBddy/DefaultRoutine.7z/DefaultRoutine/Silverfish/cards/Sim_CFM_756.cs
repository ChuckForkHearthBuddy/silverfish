using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_756 : SimTemplate //* Alley Armorsmith
	{
        // Taunt. Whenever this minion deal damage, gain that much Armor.
        //done in triggerAMinionDealedDmg (Playfield)
	}
}