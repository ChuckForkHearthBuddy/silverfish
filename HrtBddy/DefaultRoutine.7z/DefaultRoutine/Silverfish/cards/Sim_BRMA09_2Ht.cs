using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BRMA09_2Ht : SimTemplate //* 2/2 whelp
	{
		//-
	}
}