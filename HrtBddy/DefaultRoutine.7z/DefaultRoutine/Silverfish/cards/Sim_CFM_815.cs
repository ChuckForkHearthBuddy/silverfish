using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_815 : SimTemplate //* Wickerflame Burnbristle
	{
		// Taunt. Divine Shield. Damage dealt by his minion also heals your hero.
        //done in triggerAMinionDealedDmg (Playfield)
	}
}