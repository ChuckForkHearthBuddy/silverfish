using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_OG_141 : SimTemplate //* Faceless Behemoth
	{
		
	}
}