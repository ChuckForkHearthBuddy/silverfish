using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_boar : SimTemplate //boar
	{

//


	}
}