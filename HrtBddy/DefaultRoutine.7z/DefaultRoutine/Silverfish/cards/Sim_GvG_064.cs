using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_064 : SimTemplate //Puddlestomper
    {

        //   just a murloc


    }

}