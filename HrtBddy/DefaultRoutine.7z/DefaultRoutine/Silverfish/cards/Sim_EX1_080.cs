using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_080 : SimTemplate //secretkeeper
	{

//    erhält jedes mal +1/+1, wenn ein geheimnis/ ausgespielt wird.

        //we do them manually in playfield
        /*public override void onCardWasPlayed(Playfield p, CardDB.Card c, bool wasOwnCard, Minion triggerEffectMinion)
        {
            if (wasOwnCard && c.Secret)
            {
                p.minionGetBuffed(triggerEffectMinion, 1, 1);
            }
        }*/

	}
}