using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_026 : SimTemplate //* Hidden Cache
	{
		// Secret: After your opponent plays a minion, give a random minion in your hand +2/+2.
	}
}