using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_637 : SimTemplate //* Patches the Pirate
	{
		// Charge. After you play a Pirate, summon this minion from your deck.
	}
}