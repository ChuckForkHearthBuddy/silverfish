using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_KAR_070 : SimTemplate //Ethereal Peddler
    {
        // Battlecry: Reduce the Cost of cards in your hand from other classes by (2).
        
    }
}