using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_KAR_005a : SimTemplate //3/2 Big Bad Wolf
    {

    }
}