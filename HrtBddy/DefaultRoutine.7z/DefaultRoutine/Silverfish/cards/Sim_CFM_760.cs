using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_760 : SimTemplate //* Kabal Crystal Runner
	{
		// Costs (2) less for each Secret you've played this game.
	}
}