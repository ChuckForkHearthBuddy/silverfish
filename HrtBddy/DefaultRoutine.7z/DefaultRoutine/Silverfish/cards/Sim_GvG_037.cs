using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_037 : SimTemplate //Whirling Zap-o-matic
    {

        //    Windfury

        

    }

}