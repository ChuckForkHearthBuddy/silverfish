using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_OG_249a : SimTemplate //* Slime 2/2
	{
		
	}
}