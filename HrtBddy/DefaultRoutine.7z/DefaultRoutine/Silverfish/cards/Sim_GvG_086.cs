using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_086 : SimTemplate //Siege Engine
    {

        //  Whenever you gain Armor, give this minion +1 Attack. 

        // done in triggerAHeroGotArmor()


    }

}