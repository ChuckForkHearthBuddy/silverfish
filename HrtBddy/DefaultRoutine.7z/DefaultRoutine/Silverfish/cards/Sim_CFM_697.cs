using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_697 : SimTemplate //* Lotus Illusionist
	{
		// After this minion attacks a hero, transform it into a random 6-Cost minion.
        //handled
	}
}