using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_112 : SimTemplate //Mogor the Ogre
    {

        //   All minions have a 50% chance to attack the wrong enemy.

        //yolo?


    }

}