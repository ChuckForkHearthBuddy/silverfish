using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_122 : SimTemplate //Wee Spellstopper
    {

        //   Adjacent minions can't be targeted by spells or Hero Powers.




    }

}