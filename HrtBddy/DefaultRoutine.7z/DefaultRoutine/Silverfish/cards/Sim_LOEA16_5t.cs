﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_LOEA16_5t : SimTemplate //Mummy Zombies
    {
        // 3/3 Mummy Zombies.

        


    }
}