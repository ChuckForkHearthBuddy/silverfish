using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_GAME_002 : SimTemplate //avatarofthecoin
	{

//    i&gt;ihr habt den münzwurf verloren, aber einen freund gewonnen./i&gt;


	}
}