using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_324t : SimTemplate //* The Storm Guardian
	{
		// Taunt
	}
}