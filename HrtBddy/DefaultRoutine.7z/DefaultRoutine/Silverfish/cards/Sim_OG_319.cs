using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_OG_319 : SimTemplate //* Twin Emperor Vek'nilash
	{
		//Taunt
	}
}