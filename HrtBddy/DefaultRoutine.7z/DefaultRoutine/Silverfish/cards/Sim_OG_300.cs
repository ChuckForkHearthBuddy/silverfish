using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_OG_300 : SimTemplate //* The Boogeymonster
	{
		//Whenever this minion attacks and kills another minion, gain +2/+2.
		
	}
}