using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_634 : SimTemplate //* Lotus Assassin
	{
        // Stealth. Whenever this attacks and kills a minion, gain Stealth.
        //handled
	}
}