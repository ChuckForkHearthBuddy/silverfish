using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_105 : SimTemplate //mountaingiant
	{

//    kostet (1) weniger für jede andere karte auf eurer hand.

	}
}