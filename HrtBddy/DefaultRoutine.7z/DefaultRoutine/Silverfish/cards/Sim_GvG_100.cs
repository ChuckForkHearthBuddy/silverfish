using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_100 : SimTemplate //Floating Watcher
    {

        // Whenever your hero takes damage on your turn, gain +2/+2.  
        // done in triggerAMinionGotDmg
       

    }

}