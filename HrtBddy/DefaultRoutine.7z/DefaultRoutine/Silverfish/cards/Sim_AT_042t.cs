using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_042t : SimTemplate //druidoftheclaw
	{


	}
}