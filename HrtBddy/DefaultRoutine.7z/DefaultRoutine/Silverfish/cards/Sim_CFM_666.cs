using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_666 : SimTemplate //* Grook Fu Master
	{
		// Windfury
	}
}