using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_345t : SimTemplate //shadowofnothing
	{

//    gedankenspiele verpufft! euer gegner hat keine diener!
		

	}
}