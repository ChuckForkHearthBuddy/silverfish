﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_005t : SimTemplate// Boar
    {

        //Charge

       

    }
}
