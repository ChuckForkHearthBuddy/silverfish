using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_OG_123 : SimTemplate //* Shifter Zerus
	{
		//Each turn this is in your hand, transform it into a different minion.
	}
}