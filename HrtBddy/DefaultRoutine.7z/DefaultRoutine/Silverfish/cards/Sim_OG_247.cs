using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_OG_247 : SimTemplate //* Twisted Worgen
	{
		//Stealth
	}
}