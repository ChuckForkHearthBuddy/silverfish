using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_781 : SimTemplate //* Shaku, the Collector
	{
		// Stealth. Whenever this minions attacks, add a random card to your hand (from your opponent's class).
        //handled
	}
}