using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_tk34 : SimTemplate //infernal
	{

//
		

	}
}