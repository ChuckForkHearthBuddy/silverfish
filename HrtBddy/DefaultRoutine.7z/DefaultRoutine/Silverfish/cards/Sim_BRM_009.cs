﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_BRM_009 : SimTemplate //Volcanic Lumberer
    {


        //   Taunt Costs (1) less for each minion that died this turn.



    }
}