using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_586 : SimTemplate //seagiant
	{

//    kostet (1) weniger für jeden anderen diener auf dem schlachtfeld.

	}
}