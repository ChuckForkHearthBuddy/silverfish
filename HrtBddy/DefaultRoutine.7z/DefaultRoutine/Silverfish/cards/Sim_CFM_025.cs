using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CFM_025 : SimTemplate //* Wind-up Burglebot
	{
        // Whenever this attacks a minion and survives, draw a card.
        //handled
	}
}