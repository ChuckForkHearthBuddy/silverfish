using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_124 : SimTemplate //Bolf Ramshield
    {

        //Whenever your hero takes damage, this minion takes it instead.

        //done in minion -> getDamageOrHeal
       


    }

}