using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_063 : SimTemplate //Bolvar Fordragon
    {

        //   Whenever a friendly minion dies while this is in your hand, gain +1 Attack.


    }

}