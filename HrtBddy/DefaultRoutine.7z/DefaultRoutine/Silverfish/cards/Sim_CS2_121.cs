using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_121 : SimTemplate //frostwolfgrunt
	{

//    spott/


	}
}