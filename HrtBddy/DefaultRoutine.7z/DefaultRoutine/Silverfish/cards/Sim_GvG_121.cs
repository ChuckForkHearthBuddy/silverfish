using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_121 : SimTemplate //Clockwork Giant
    {

        //   Costs (1) less for each card in your opponent's hand.



    }

}