using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_tt_010a : SimTemplate //spellbender
	{

//    zauberformerin
		

	}
}