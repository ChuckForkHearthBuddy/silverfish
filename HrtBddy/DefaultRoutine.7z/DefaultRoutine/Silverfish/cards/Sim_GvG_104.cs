using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_104 : SimTemplate //Hobgoblin
    {

        //  Whenever you play a 1-Attack minion, give it +2/+2 

        // done in triggerACardWillBePlayed

    }

}