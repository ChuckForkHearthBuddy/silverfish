using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_KAR_710m : SimTemplate //Animated Shield
    {
        //

    }
}