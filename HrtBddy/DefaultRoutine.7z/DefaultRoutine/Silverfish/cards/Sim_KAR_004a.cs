using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_KAR_004a : SimTemplate //Cat in a Hat
    {
        // Stealth

    }
}