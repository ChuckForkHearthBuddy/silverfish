using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_085 : SimTemplate //Annoy-o-Tron
    {

        //   Taunt Divine Shield

        


    }

}