using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_LOE_019 : SimTemplate //unearthed raptor
	{
        //Battlecry: Choose a friendly minion. Gain a copy of its Deathrattle effect.

        public override void getBattlecryEffect(Playfield p, Minion own, Minion target, int choice)
        {
            //TODO
        }

	}

}
