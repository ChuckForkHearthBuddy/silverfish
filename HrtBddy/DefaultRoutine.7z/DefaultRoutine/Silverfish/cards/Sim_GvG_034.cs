using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_034 : SimTemplate //Mech-Bear-Cat
    {

        //    Whenever this minion takes damage, add a Spare Part card to your hand.

        //handled in triggerAMinionGotDmg() (to few minions have this to do it here)

    }

}