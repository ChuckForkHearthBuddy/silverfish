using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_084 : SimTemplate //Flying Machine<
    {

        //   Windfury


    }

}