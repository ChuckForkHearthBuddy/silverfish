using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_KAR_025c : SimTemplate //3/3 Teapot
    {

    }
}