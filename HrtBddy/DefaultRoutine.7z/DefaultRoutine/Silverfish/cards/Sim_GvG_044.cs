using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_044 : SimTemplate //Spider Tank
    {

        //   just a spider tank :D

        


    }

}