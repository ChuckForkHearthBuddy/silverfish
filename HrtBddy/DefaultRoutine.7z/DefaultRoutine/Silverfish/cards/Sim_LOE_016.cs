using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_LOE_016 : SimTemplate //Rumbling Elemental
	{

        //    After you play a Battlecry minion, deal 2 damage to a random enemy.

        //done in playfield trigger a card was played


	}
}